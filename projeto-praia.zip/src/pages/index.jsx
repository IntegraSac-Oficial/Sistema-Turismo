import Public from "./Public";

export default function Index() {
  return <Public />;
}